console.log("Hello world");
var a=1;
var b=2;
var r=a+b;
console.log("Resultado :"+r);

var s=5;
var v=2;
var c=s*v;
console.log("Resultado :" + c);

var ra=Math. sqrt (1442);
var mo=Math. trunc(ra);
console.log("resultado decimal:"+ra);
console.log("resultado:"+mo);